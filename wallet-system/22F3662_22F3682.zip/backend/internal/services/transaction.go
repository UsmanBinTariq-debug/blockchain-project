package services

import (
	"context"
	"crypto-wallet-backend/internal/database"
)

// TransactionService handles transaction operations
type TransactionService struct {
	db *database.Database
}

// NewTransactionService creates a new transaction service
func NewTransactionService(db *database.Database) *TransactionService {
	return &TransactionService{db: db}
}

// GetTransactionHistory retrieves transaction history for a wallet
func (ts *TransactionService) GetTransactionHistory(ctx context.Context, walletAddress string, limit, offset int) ([]*database.Transaction, error) {
	return ts.db.GetTransactionsByWallet(ctx, walletAddress, limit, offset)
}

// GetTransactionByHash retrieves a transaction by hash
func (ts *TransactionService) GetTransactionByHash(ctx context.Context, hash string) (*database.Transaction, error) {
	return ts.db.GetTransactionByHash(ctx, hash)
}

// UpdateTransactionStatus updates transaction status
func (ts *TransactionService) UpdateTransactionStatus(ctx context.Context, txHash, status string) error {
	// This would require adding an update method to the database service
	return nil
}
