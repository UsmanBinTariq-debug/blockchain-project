import React, { useEffect, useState } from 'react'

const BlockExplorer: React.FC = () => {
  const [blocks, setBlocks] = useState([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    // Load blocks
    // const loadBlocks = async () => {
    //   try {
    //     setLoading(true)
    //     const response = await apiClient.getBlocks()
    //     if (response.data.status === 'success') {
    //       setBlocks(response.data.data)
    //     }
    //   } catch (error) {
    //     console.error('Failed to load blocks:', error)
    //   } finally {
    //     setLoading(false)
    //   }
    // }
    // loadBlocks()
  }, [])

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-800 dark:text-white">Block Explorer</h1>

      <div className="card">
        {loading ? (
          <p className="text-center text-gray-600 dark:text-gray-400">Loading...</p>
        ) : blocks.length === 0 ? (
          <p className="text-center text-gray-600 dark:text-gray-400">No blocks found</p>
        ) : (
          <div className="space-y-4">
            {blocks.map((block: any) => (
              <div key={block.id} className="border border-gray-200 dark:border-gray-700 p-4 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-800 dark:text-white">
                  Block #{block.blockIndex}
                </h3>
                <div className="grid grid-cols-2 gap-4 mt-2 text-sm">
                  <div>
                    <span className="text-gray-600 dark:text-gray-400">Hash:</span>
                    <p className="text-gray-800 dark:text-white font-mono truncate">{block.hash}</p>
                  </div>
                  <div>
                    <span className="text-gray-600 dark:text-gray-400">Nonce:</span>
                    <p className="text-gray-800 dark:text-white">{block.nonce}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

export default BlockExplorer
