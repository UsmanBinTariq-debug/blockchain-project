import React, { useEffect, useState } from 'react'
import { useWalletStore } from '../utils/store'

const Dashboard: React.FC = () => {
  const wallet = useWalletStore((state) => state.wallet)
  const balance = useWalletStore((state) => state.balance)
  const [recentTransactions, setRecentTransactions] = useState([])

  useEffect(() => {
    // Load wallet data
    // const loadWallet = async () => {
    //   try {
    //     const response = await apiClient.getWallet()
    //     if (response.data.status === 'success') {
    //       useWalletStore.setState({ wallet: response.data.data })
    //     }
    //   } catch (error) {
    //     console.error('Failed to load wallet:', error)
    //   }
    // }
    // loadWallet()
  }, [])

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-800 dark:text-white">Dashboard</h1>

      {/* Balance Card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="card bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <h2 className="text-lg font-semibold mb-2">Total Balance</h2>
          <p className="text-4xl font-bold">{balance.toFixed(8)} CRW</p>
          <p className="text-sm mt-2 opacity-75">Crypto Wallet Token</p>
        </div>

        <div className="card">
          <h2 className="text-lg font-semibold mb-2 text-gray-800 dark:text-white">Monthly Zakat</h2>
          <p className="text-2xl font-bold text-green-600">{(balance * 0.025).toFixed(8)}</p>
          <p className="text-sm mt-2 text-gray-600 dark:text-gray-400">2.5% Deducted Monthly</p>
        </div>

        <div className="card">
          <h2 className="text-lg font-semibold mb-2 text-gray-800 dark:text-white">Active Wallet</h2>
          <p className="text-sm font-mono break-all text-gray-700 dark:text-gray-300">
            {wallet?.walletAddress?.substring(0, 16)}...
          </p>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="card">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">Quick Actions</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <a href="/send-money" className="btn-primary text-center">Send Money</a>
          <a href="/wallet" className="btn-secondary text-center">View Wallet</a>
          <a href="/transactions" className="btn-secondary text-center">Transactions</a>
          <a href="/block-explorer" className="btn-secondary text-center">Explorer</a>
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="card">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">Recent Transactions</h2>
        {recentTransactions.length === 0 ? (
          <p className="text-gray-600 dark:text-gray-400">No transactions yet</p>
        ) : (
          <div className="space-y-2">
            {/* Transaction list would go here */}
          </div>
        )}
      </div>
    </div>
  )
}

export default Dashboard
