import React from 'react'

const Reports: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-800 dark:text-white">Reports</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="card">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">
            Monthly Summary
          </h2>
          <p className="text-gray-600 dark:text-gray-400">No data available</p>
        </div>

        <div className="card">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">
            Zakat Report
          </h2>
          <p className="text-gray-600 dark:text-gray-400">No zakat transactions yet</p>
        </div>
      </div>
    </div>
  )
}

export default Reports
