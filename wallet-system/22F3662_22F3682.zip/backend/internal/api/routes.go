package api

import (
	"github.com/gin-gonic/gin"
)

// SetupRoutes sets up all API routes
func SetupRoutes(router *gin.Engine, handler *Handler) {
	// Health check
	router.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{"status": "ok"})
	})

	// Authentication routes
	auth := router.Group("/api/auth")
	{
		auth.POST("/register", handler.RegisterHandler)
		auth.POST("/login", handler.LoginHandler)
	}

	// Wallet routes
	wallet := router.Group("/api/wallet")
	wallet.Use(AuthMiddleware(handler.jwtSecret))
	{
		wallet.GET("/profile", handler.GetWalletHandler)
		wallet.POST("/balance", handler.GetBalanceHandler)
	}

	// Blockchain routes
	blockchain := router.Group("/api/blockchain")
	{
		blockchain.GET("/blocks", func(c *gin.Context) {
			// Get all blocks
			c.JSON(200, gin.H{"blocks": []interface{}{}})
		})
		blockchain.GET("/blocks/:hash", func(c *gin.Context) {
			// Get block by hash
			c.JSON(200, gin.H{"block": nil})
		})
	}

	// Transaction routes
	transaction := router.Group("/api/transaction")
	{
		transaction.GET("/pending", func(c *gin.Context) {
			// Get pending transactions
			c.JSON(200, gin.H{"transactions": []interface{}{}})
		})
	}
}
