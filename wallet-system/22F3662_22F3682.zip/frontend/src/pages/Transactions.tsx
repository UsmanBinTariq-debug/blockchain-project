import React, { useEffect, useState } from 'react'

const Transactions: React.FC = () => {
  const [transactions, setTransactions] = useState([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    // Load transactions
    // const loadTransactions = async () => {
    //   try {
    //     setLoading(true)
    //     const response = await apiClient.getTransactionHistory(walletAddress)
    //     if (response.data.status === 'success') {
    //       setTransactions(response.data.data)
    //     }
    //   } catch (error) {
    //     console.error('Failed to load transactions:', error)
    //   } finally {
    //     setLoading(false)
    //   }
    // }
    // loadTransactions()
  }, [])

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-800 dark:text-white">Transactions</h1>

      <div className="card">
        {loading ? (
          <p className="text-center text-gray-600 dark:text-gray-400">Loading...</p>
        ) : transactions.length === 0 ? (
          <p className="text-center text-gray-600 dark:text-gray-400">No transactions found</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-100 dark:bg-gray-700">
                <tr>
                  <th className="px-4 py-2 text-left">Hash</th>
                  <th className="px-4 py-2 text-left">From</th>
                  <th className="px-4 py-2 text-left">To</th>
                  <th className="px-4 py-2 text-right">Amount</th>
                  <th className="px-4 py-2 text-center">Status</th>
                  <th className="px-4 py-2 text-left">Date</th>
                </tr>
              </thead>
              <tbody>
                {/* Transactions would be rendered here */}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}

export default Transactions
