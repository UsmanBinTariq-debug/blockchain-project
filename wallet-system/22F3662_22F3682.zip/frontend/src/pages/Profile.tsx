import React from 'react'
import { useAuthStore } from '../utils/store'

const Profile: React.FC = () => {
  const user = useAuthStore((state) => state.user)

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-800 dark:text-white">Profile</h1>

      <div className="card max-w-2xl">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">
          User Information
        </h2>

        {user ? (
          <div className="space-y-4">
            <div>
              <label className="text-gray-600 dark:text-gray-400">Full Name</label>
              <p className="text-gray-800 dark:text-white font-semibold">{user.fullName}</p>
            </div>

            <div>
              <label className="text-gray-600 dark:text-gray-400">Email</label>
              <p className="text-gray-800 dark:text-white font-semibold">{user.email}</p>
            </div>

            <div>
              <label className="text-gray-600 dark:text-gray-400">CNIC</label>
              <p className="text-gray-800 dark:text-white font-semibold">{user.cnic}</p>
            </div>

            <div>
              <label className="text-gray-600 dark:text-gray-400">Wallet ID</label>
              <p className="text-gray-800 dark:text-white font-mono text-sm">{user.walletId}</p>
            </div>

            <div>
              <label className="text-gray-600 dark:text-gray-400">Verification Status</label>
              <p className="text-gray-800 dark:text-white">
                {user.isVerified ? (
                  <span className="text-green-600 font-semibold">✓ Verified</span>
                ) : (
                  <span className="text-orange-600 font-semibold">⏳ Pending</span>
                )}
              </p>
            </div>
          </div>
        ) : (
          <p className="text-gray-600 dark:text-gray-400">No user data</p>
        )}
      </div>
    </div>
  )
}

export default Profile
