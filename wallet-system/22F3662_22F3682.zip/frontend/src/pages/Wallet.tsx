import React, { useState } from 'react'
import { useWalletStore } from '../utils/store'

const Wallet = () => {
  const wallet = useWalletStore((state) => state.wallet)
  const [copied, setCopied] = useState(false)

  React.useEffect(() => {
    const token = localStorage.getItem('auth_token')
    console.log('[Wallet] mount - token:', token ? token.substring(0, 20) + '...' : null)
    console.log('[Wallet] mount - wallet state:', wallet)
  }, [wallet])

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-800 dark:text-white">Wallet</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Wallet Address */}
        <div className="card">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">
            Wallet Address
          </h2>
          <div className="space-y-4">
            <div className="p-4 bg-gray-100 dark:bg-gray-700 rounded-lg break-all font-mono text-sm">
              {wallet?.wallet_address || 'Loading...'}
            </div>
            <button
              onClick={() => copyToClipboard(wallet?.wallet_address || '')}
              className="btn-primary w-full"
            >
              {copied ? 'Copied!' : 'Copy Address'}
            </button>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="card">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">
            Quick Actions
          </h2>
          <div className="space-y-2">
            <button onClick={() => copyToClipboard(wallet?.wallet_address || '')} className="btn-secondary w-full">
              Copy Wallet ID
            </button>
            <button className="btn-secondary w-full">View Transactions</button>
          </div>
        </div>
      </div>

      {/* Wallet Information */}
      <div className="card">
        <h2 className="text-xl font-semibold text-gray-800 dark:text-white mb-4">
          Wallet Information
        </h2>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-gray-600 dark:text-gray-400">User ID</label>
              <p className="text-gray-800 dark:text-white font-mono text-sm">
                {wallet?.user_id?.substring(0, 8)}...
              </p>
            </div>
            <div>
              <label className="text-gray-600 dark:text-gray-400">Last Updated</label>
              <p className="text-gray-800 dark:text-white">
                {wallet?.last_updated ? new Date(wallet.last_updated).toLocaleDateString() : 'N/A'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Wallet
